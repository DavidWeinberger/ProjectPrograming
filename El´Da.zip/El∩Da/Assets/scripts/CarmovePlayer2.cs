﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarmovePlayer2 : MonoBehaviour {

    
	public float Geschwindigkeit;
	public float Beschleunigung;
    static float rot = 0;


	float aktuelleGeschwindigkeit = 0;
	Vector3 richtung = Vector3.zero;

	void Start()
	{
	}

	void Update()
	{
		if (EingabeÜberprüfen())
		{
			if (aktuelleGeschwindigkeit < Geschwindigkeit)
			{
				aktuelleGeschwindigkeit += Beschleunigung * Time.deltaTime;
			}
			this.transform.position += richtung * aktuelleGeschwindigkeit * Time.deltaTime;
			//this.transform.Rotate(new Vector3(this.transform.position.x,this.transform.position.y,this.transform.position.z));
		}
		else
		{
			aktuelleGeschwindigkeit = 0f;
		}
	}

	private bool EingabeÜberprüfen()
	{
		bool eingabe = false;
        bool leftRight = false;
		float x = 0f;
		float z = 0f;
        float localRot = rot;


		// Input.GetKey gibt true zurück wenn
		// die gefragte Taste gedrückt ist

		if (Input.GetKey(KeyCode.D))
		{
            localRot = localRot + 0.1f;
            localRot = localRot % 360;
            
            eingabe = true;
            leftRight = true;
		}
        if (Input.GetKey(KeyCode.A))
		{
            localRot = localRot - 0.1f;
            if ((int) localRot < 0)
            {
                localRot += 360;
            }            
            localRot = localRot % 360;
			eingabe = true;
            leftRight = true;
		}
        if (Input.GetKey(KeyCode.W))
		{
            richtung = new Vector3(Mathf.Sin(localRot), Mathf.Cos(localRot), 0f);
            
			eingabe = true;
		}
        if (Input.GetKey(KeyCode.S))
		{
            richtung = new Vector3(-Mathf.Sin(localRot), -Mathf.Cos(localRot), 0f);

            eingabe = true;
        }
       
        rot = localRot;
       /* if (leftRight == true)
        {
            this.transform.Rotate(new Vector3(0, 0, 720-2*localRot), Space.World);
        }*/
        return eingabe;
	}
}
