﻿using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarmovePlayer1 : MonoBehaviour {

    
	public float Geschwindigkeit;
	public float Beschleunigung;

	float aktuelleGeschwindigkeit = 0;
    Vector3 richtung = new Vector3(0, 0, 0);

	void Start()
	{
	}

	void Update()
	{
		if (EingabeÜberprüfen())
		{
			if (aktuelleGeschwindigkeit < Geschwindigkeit)
			{
                aktuelleGeschwindigkeit += Beschleunigung * Time.deltaTime;
			}
            else
            {
                aktuelleGeschwindigkeit = Geschwindigkeit;
            }
            this.transform.position += richtung * aktuelleGeschwindigkeit * Time.deltaTime;

		}
		else
		{
            aktuelleGeschwindigkeit = 0f;
		}
	}

	private bool EingabeÜberprüfen()
	{       
		bool left_right = false;
		bool eingabe = false;
		int x = 0;
		int y = 0;
        int localRoat = (int)this.transform.eulerAngles.z;
        // Input.GetKey gibt true zurück wenn
        // die gefragte Taste gedrückt ist

        if (Input.GetKey(KeyCode.RightArrow) && eingabe == false)
		{
            localRoat += -5;
            if(localRoat < -180)
            {
                localRoat = 360 + localRoat;
            }            
            left_right = true;
			eingabe = true;
		}

		if (Input.GetKey(KeyCode.LeftArrow) && eingabe == false)
		{
            localRoat += 5;
            if(localRoat == 180)
            {
                localRoat = -180;
            }
            else if(localRoat > 180)
            {
                localRoat = 360 - localRoat;
            }
            left_right = true;
            eingabe = true;
        }

		if (Input.GetKey(KeyCode.UpArrow) && eingabe == false)
		{
            x += (int)System.Math.Sin(localRoat);
            y += (int)System.Math.Cos(localRoat);
		}

		if (Input.GetKey(KeyCode.DownArrow) && eingabe == false)
		{			
			y--;			
			eingabe = true;
		}

        richtung = new Vector3((float)x,(float)y, 0);
		if (eingabe == true && left_right == true) {

			this.transform.Rotate(new Vector3(0,0,localRoat), Space.World);
        }        
        System.Threading.Thread.Sleep(100);
		return eingabe;
	}
}
